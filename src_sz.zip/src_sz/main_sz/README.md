﻿# Terras Devastadas
---

### Nome do site - Graco

### Integrantes:
Nome | Matrícula
--|--
Maria Luisa Alves | 211039617
Tiago Albuquerque | 202028973
Samuel Ricardo Dias da Silva | 211031495
Leonardo Lago Moreno | 211031762
Sebastian Hector Zuzunaga Rosado | 211006957

### Sobre o projeto:

### Como executar:
##### Front-end
Atualmente o front-end consiste em uma aplicação envolvendo **HTML** e **CSS**,com as páginas sem estarem conectadas. Portanto, para a vizualização das mesmas basta abrir os arquivos que se encontram na pasta `src` em um navegador.  


##### Back-end
 Antes de rodar o código é necessário executar o comando `yarn init`, depois, use o comando `yarn dev`




>>>>>>> 7ef050c5dad00226e14da07a33e38d27780c423b:main_sz/README.md
