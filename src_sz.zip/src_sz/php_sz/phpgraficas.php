<?php
        $user=['nombre_prova','123456','curso_prova','estado_prova'];
        $voltar=[50,45,12,34,56,78,54,12,34];
        $vacur=[45,33,54,11,33,44,55,66,77,88,44,22];
        $aluvac=23;
        $alurec=45;
        $alucon=34;
?>